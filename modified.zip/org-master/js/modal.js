function kavita(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("name").innerHTML="Kavita Shekhawat";
    document.getElementById("position").innerHTML="";
    document.getElementById("branch").innerHTML="Branch: Mechanical Engineering";
    document.getElementById("achieve").innerHTML="Achievement: "
}
function shanur(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("name").innerHTML="Shanur Rahman";
    document.getElementById("position").innerHTML="";
    document.getElementById("branch").innerHTML="Branch: Computer Science & Engineering";
    document.getElementById("achieve").innerHTML="Achievement: "
}
function kumar(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("name").innerHTML="Kumar Pranshu";
    document.getElementById("position").innerHTML="";
    document.getElementById("branch").innerHTML="Branch: Mechanical Engineering";
    document.getElementById("achieve").innerHTML="Achievement: "
}
function sri(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("name").innerHTML="Sri Hari Satya Bhardwaj V";
    document.getElementById("position").innerHTML="";
    document.getElementById("branch").innerHTML="Branch: Mechanical Engineering";
    document.getElementById("achieve").innerHTML="Achievement: "
}
function vishal(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("name").innerHTML="Vishal Kumar";
    document.getElementById("branch").innerHTML="Branch: Mechanical Engineering";
    document.getElementById("achieve").innerHTML="Achievement: "
}
function vasu(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("name").innerHTML="V.Vasudeva Reddy";
    document.getElementById("position").innerHTML="";
    document.getElementById("branch").innerHTML="Branch: Mechanical Engineering";
    document.getElementById("achieve").innerHTML="Achievement: "
}
function bal(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("name").innerHTML="Baljinder Sidhu";
    document.getElementById("branch").innerHTML="Branch: Mechanical Engineering";
    document.getElementById("position").innerHTML="";
    document.getElementById("achieve").innerHTML="Achievement: "
}
function kalyan(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("name").innerHTML="Pandrangi Kalyan";
    document.getElementById("position").innerHTML="(Student Coordinator)";
    document.getElementById("branch").innerHTML="Mechanical Engineering";
    document.getElementById("achieve").innerHTML="Achievement: "
}
function asad(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("name").innerHTML="Asad Salah";
    document.getElementById("branch").innerHTML="Mechanical Engineering";
    document.getElementById("position").innerHTML="(Student Coordinator)";
    document.getElementById("achieve").innerHTML="Achievement: "
}
function shubhi(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("name").innerHTML="Shubhi Sharma";
    document.getElementById("position").innerHTML="(Student Co-Coordinator)";
    document.getElementById("branch").innerHTML=" Electronics & Comm. Engineering";
    document.getElementById("achieve").innerHTML="Achievement: "
}
function dillu(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("name").innerHTML="Dilkush Kumar";
    document.getElementById("position").innerHTML="(Programming Head)";
    document.getElementById("branch").innerHTML=" Computer Science & Engineering";
    document.getElementById("achieve").innerHTML="Achievement: "
}
function yasho(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("name").innerHTML="Yashovardhan Sharma";
    document.getElementById("position").innerHTML="(Electronics Head)";
    document.getElementById("branch").innerHTML=" Electronics & Comm. Engineering";
    document.getElementById("achieve").innerHTML="Achievement: "
}
function harsh(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("name").innerHTML="Harsh";
    document.getElementById("position").innerHTML="(Mechanical & Fabrication Head)";
    document.getElementById("branch").innerHTML=" Mechanical Engineering";
    document.getElementById("achieve").innerHTML="Achievement: "
}
function piyush(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("name").innerHTML="Piyush Raj Anand";
    document.getElementById("position").innerHTML="(Planning-Management & Documentation Head)";
    document.getElementById("branch").innerHTML=" Computer Science & Engineering";
    document.getElementById("achieve").innerHTML="Achievement: "
}
function ashwini(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("name").innerHTML="Ashwini Kumar";
    document.getElementById("position").innerHTML="(Financial Head)";
    document.getElementById("branch").innerHTML="Electrical Engineering";
    document.getElementById("achieve").innerHTML="Achievement: "
}
function rahul(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("name").innerHTML="Rahul Kake";
    document.getElementById("skills").innerHTML="Skills: C / C++, Python, ethical hacking ";
    document.getElementById("position").innerHTML="(Assets Manager)";
    document.getElementById("branch").innerHTML=" Computer Science & Engineering";
    document.getElementById("achieve").innerHTML="Achievement: "
}
function apurva(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("name").innerHTML="Apurva Akriti";
    document.getElementById("position").innerHTML="(Marketing & Promotion Head)";
    document.getElementById("branch").innerHTML="Electronics & Comm. Engineering";
    document.getElementById("achieve").innerHTML="Achievement: "
}
function amrita(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("name").innerHTML="Amritanjali Kumari";
    document.getElementById("position").innerHTML="(Marketing & Promotion Head)";
    document.getElementById("branch").innerHTML=" Electronics & Comm. Engineering";
    document.getElementById("achieve").innerHTML="Achievement: "
}
function shashank(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("name").innerHTML="Shashank Singh";
    document.getElementById("doj").innerHTML=" 2018";
    document.getElementById("about").innerHTML="";
    document.getElementById("skills").innerHTML=" C / C++, Python, Catia, Arduino ";
    document.getElementById("position").innerHTML=" ";
    document.getElementById("branch").innerHTML="Electronics & Comm. Engineering";
    document.getElementById("achieve").innerHTML="Achievement: "
    
}
function vikrant(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML=" 2017";
    document.getElementById("about").innerHTML=" hello everyone";
    document.getElementById("skills").innerHTML="";
    document.getElementById("name").innerHTML="Vikrant Kumar";
    document.getElementById("branch").innerHTML=" Computer Science & Engineering";
   
}
function soham(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML="2019";
    document.getElementById("about").innerHTML=" I am a smart working person.";
    document.getElementById("skills").innerHTML="C / C++, Catia, Arduino, Proteus";
    document.getElementById("name").innerHTML="Soham Das";
    document.getElementById("branch").innerHTML=" Mechanical Engineering";
    
}
function aashita(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML="2019";
    document.getElementById("about").innerHTML=" Dedicated and hardworking person who loves to work";
    document.getElementById("skills").innerHTML="C / C++, Catia, Arduino, Proteus";
    document.getElementById("name").innerHTML="Aashita Saran";
    document.getElementById("branch").innerHTML="Mechanical Engineering";
    
}
function srp(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML="2019";
    document.getElementById("about").innerHTML=" Disciplined and curious";
    document.getElementById("skills").innerHTML=" C / C++";
    document.getElementById("name").innerHTML="Satvik Raj Patel";
    document.getElementById("branch").innerHTML="Electronics & Comm. Engineering";
    
}
function antara(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML=" 2019";
    document.getElementById("about").innerHTML="Dedicated and hardworking person who loves to work";
    document.getElementById("skills").innerHTML=" C / C++, Catia, Arduino, Proteus";
    document.getElementById("name").innerHTML="Antara Singh";
    document.getElementById("branch").innerHTML=" Electrical Engineering";
    
}
function ayushR(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML="2019";
    document.getElementById("about").innerHTML="I am punctual and want to learn something new. ";
    document.getElementById("skills").innerHTML=" C / C++, Catia, Arduino, Proteus";
    document.getElementById("name").innerHTML="Ayush Rai";
    document.getElementById("branch").innerHTML="Mechanical Engineering";
    
}
function utsav(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML="2019";
    document.getElementById("about").innerHTML="Always trying to learn something";
    document.getElementById("skills").innerHTML=" C / C++, Arduino";
    document.getElementById("name").innerHTML="Utsav Anand";
    document.getElementById("branch").innerHTML="Electrical Engineering";
    
}
function kartik(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML="2019";
    document.getElementById("about").innerHTML="I'm a tech freak and always trying to perform better then yesterday";
    document.getElementById("skills").innerHTML="IoT,Java,HTML,CSS, Javascript";
    document.getElementById("name").innerHTML="Aayush Kartik";
    document.getElementById("branch").innerHTML=" Mechanical Engineering";
    
}
function kundan(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML="2019";
    document.getElementById("about").innerHTML=" Always trying to learn something";
    document.getElementById("skills").innerHTML="C / C++, Webdevelopment";
    document.getElementById("name").innerHTML="Kundan Kumar";
    document.getElementById("branch").innerHTML=" Electrical Engineering";
    
}
function avinash(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML="2019";
    document.getElementById("about").innerHTML="Always trying to learn something";
    document.getElementById("skills").innerHTML=" C / C++, Arduino";
    document.getElementById("name").innerHTML="Avinash Kumar";
    document.getElementById("branch").innerHTML="Computer Science & Engineering";
    
}
function bhagwat(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML="2019";
    document.getElementById("about").innerHTML="Always trying to learn something";
    document.getElementById("skills").innerHTML=" C / C++, Arduino";
    document.getElementById("name").innerHTML="Bhagwat Shandilya";
    document.getElementById("branch").innerHTML="Computer Science & Engineering";
    
}
function mahesh(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML=" 2018";
    document.getElementById("about").innerHTML=" i always Imagine and think about how the thing works this made me curious to know more and more.";
    document.getElementById("skills").innerHTML=" C / C++, Catia, Arduino, Proteus";
    document.getElementById("name").innerHTML="Mahesh Yadav";
    document.getElementById("branch").innerHTML=" Electrical Engineering";
    
}
function saurav(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML="2019";
    document.getElementById("about").innerHTML="Always trying to learn something";
    document.getElementById("skills").innerHTML=" C / C++, Arduino";
    document.getElementById("name").innerHTML="Saurav Sanjay";
    document.getElementById("branch").innerHTML="Computer Science & Engineering";
}
function krishna(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML="2018";
    document.getElementById("about").innerHTML="I am hardworking and consistently set firm goals for myself.";
    document.getElementById("skills").innerHTML=" C / C++, Catia, MS office, excel, power point, word";
    document.getElementById("name").innerHTML="Krishna Kumar";
    document.getElementById("branch").innerHTML="Mechanical Engineering";
    
}
function abhi(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML="2018";
    document.getElementById("about").innerHTML="Better to grow together then alone, always happy to help";
    document.getElementById("skills").innerHTML=" C / C++, Catia, Machine Learning";
    document.getElementById("name").innerHTML="Abhishek Yadav";
    document.getElementById("branch").innerHTML="Mechanical Engineering";
    
}
function ashishK(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML="2019";
    document.getElementById("about").innerHTML="Better to grow together then alone, always happy to help";
    document.getElementById("skills").innerHTML=" Catia, Arduino, Proteus, PLC";
    document.getElementById("name").innerHTML="Ashish Kumar";
    document.getElementById("branch").innerHTML="Electrical Engineering";
}
function annanya(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML="2019";
    document.getElementById("about").innerHTML=" always happy to help";
    document.getElementById("skills").innerHTML=" C/C++";
    document.getElementById("name").innerHTML="Annanya Mehta";
    document.getElementById("branch").innerHTML="Computer Science & Engineering";
}
function ashish(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML="2019";
    document.getElementById("about").innerHTML="Better to grow together then alone, always happy to help";
    document.getElementById("skills").innerHTML=" Catia, Arduino, Proteus, PLC";
    document.getElementById("name").innerHTML="Ashish Kumar";
    document.getElementById("branch").innerHTML="Electrical Engineering";
}
function ishu(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML="2019";
    document.getElementById("about").innerHTML="I am hard working person ";
    document.getElementById("skills").innerHTML="Catia, Ansys, Solid Works, Arduino, Proteus";
    document.getElementById("name").innerHTML="Ishu Shukralia";
    document.getElementById("branch").innerHTML=" Mechanical Engineering";
}
function anant(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML="2019";
    document.getElementById("about").innerHTML="I am devoted to everything which I want ...... ";
    document.getElementById("skills").innerHTML="C/C++ , Aurdino, Proteus";
    document.getElementById("name").innerHTML="Anant Thakur";
    document.getElementById("branch").innerHTML=" Mechanical Engineering";
}
function priyanka(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML="2019";
    document.getElementById("about").innerHTML="Helpful ";
    document.getElementById("skills").innerHTML="C / C++, Catia, Arduino, Proteus";
    document.getElementById("name").innerHTML="Priyanka Kumari";
    document.getElementById("branch").innerHTML=" Electronics & Comm. Engineering";
}
function shiv(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML="2019";
    document.getElementById("about").innerHTML="I never give up until I get something right ";
    document.getElementById("skills").innerHTML="C / C++, Python";
    document.getElementById("name").innerHTML="Shivotkarsh Raj";
    document.getElementById("branch").innerHTML=" Electronics & Comm. Engineering";
}
function akshay(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML="2019";
    document.getElementById("about").innerHTML="I never give up until I get something right ";
    document.getElementById("skills").innerHTML="C / C++, Python";
    document.getElementById("name").innerHTML="Akshay Kumar";
    document.getElementById("branch").innerHTML=" Electronics & Comm. Engineering";
}
function ritik(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML="2018";
    document.getElementById("about").innerHTML="I never give up until I get something right ";
    document.getElementById("skills").innerHTML="C / C++, Python, Opencv, machine learning";
    document.getElementById("name").innerHTML="Ritik Khandelwal";
    document.getElementById("branch").innerHTML="Computer Science & Engineering";
}
function vimal(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML="2019";
    document.getElementById("about").innerHTML="I am man who can do hard work continuously. ";
    document.getElementById("skills").innerHTML="C / C++, Python, Catia, Matlab, Arduino, Proteus";
    document.getElementById("name").innerHTML="Vimal Kumar Verma";
    document.getElementById("branch").innerHTML="Electronics & Comm. Engineering";
}
function akshat(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML="2019";
    document.getElementById("about").innerHTML="I put myself in the way of things happening, and they happened. ";
    document.getElementById("skills").innerHTML="C / C++, Catia, Matlab, Arduino, Proteus";
    document.getElementById("name").innerHTML="Akshat Verma";
    document.getElementById("branch").innerHTML="Mechanical Engineering";
}
function azar(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML="2018";
    document.getElementById("about").innerHTML="I put myself in the way of things happening, and they happened. ";
    document.getElementById("skills").innerHTML="C / C++, Catia, Arduino, Proteus";
    document.getElementById("name").innerHTML="Md. Azharuddin";
    document.getElementById("branch").innerHTML="Electrical Engineering";
}
function princu(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML="2018";
    document.getElementById("about").innerHTML="I put myself in the way of things happening, and they happened. ";
    document.getElementById("skills").innerHTML="C / C++, Catia, Arduino, Proteus";
    document.getElementById("name").innerHTML="Princu Singh";
    document.getElementById("branch").innerHTML="Mechanical Engineering";
}
function anjani(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML="2018";
    document.getElementById("about").innerHTML="prove them wrong ";
    document.getElementById("skills").innerHTML="C / C++, Python, Catia, Matlab, Arduino";
    document.getElementById("name").innerHTML="Anjani Tiwari";
    document.getElementById("branch").innerHTML="Mechanical Engineering";
}
function bhanu(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML="2018";
    document.getElementById("about").innerHTML="prove them wrong ";
    document.getElementById("skills").innerHTML="C / C++, Catia";
    document.getElementById("name").innerHTML="Bhanu Pratap";
    document.getElementById("branch").innerHTML="Mechanical Engineering";
}
function aditya(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML="2018";
    document.getElementById("about").innerHTML="hard working person ";
    document.getElementById("skills").innerHTML=" Catia, Matlab, Arduino";
    document.getElementById("name").innerHTML="Aditya Gupta";
    document.getElementById("branch").innerHTML="Mechanical Engineering";
}
function shubham(){
    document.querySelector(" .modal").style.display = "flex";
    document.getElementById("position").innerHTML="";
    document.getElementById("doj").innerHTML="2018";
    document.getElementById("about").innerHTML="prove them wrong ";
    document.getElementById("skills").innerHTML="C / C++, Python, Catia, Matlab, Arduino";
    document.getElementById("name").innerHTML="Shubham kumar";
    document.getElementById("branch").innerHTML="Electronics & Comm. Engineering";
}
function closed(){
    document.querySelector(" .modal").style.display = "none";
}